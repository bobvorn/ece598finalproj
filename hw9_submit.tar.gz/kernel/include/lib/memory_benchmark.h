void memset_benchmark(uint32_t memory_total,uint32_t kernel_end);
void memcpy_benchmark(uint32_t memory_total);
