void *memcpy(void *dest, const void *src, uint32_t n);

