void drivers_init_all(void);
