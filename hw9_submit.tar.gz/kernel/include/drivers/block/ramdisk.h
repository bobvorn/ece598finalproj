int32_t ramdisk_read(uint32_t offset, uint32_t length, char *dest);
int32_t ramdisk_init(unsigned char *start, uint32_t length);


