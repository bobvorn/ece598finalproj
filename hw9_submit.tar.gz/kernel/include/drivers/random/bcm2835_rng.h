int bcm2835_rng_init(void);
int bcm2835_rng_exit(void);
int32_t bcm2835_rng_read(uint32_t *value);
