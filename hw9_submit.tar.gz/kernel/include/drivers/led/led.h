int led_init(void);
int led_on(void);
int led_off(void);

void emergency_blink(void);
