int thermal_read(void);
