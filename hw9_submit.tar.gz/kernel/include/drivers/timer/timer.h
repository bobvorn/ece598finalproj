int timer_init(void);
void timer_interrupt_handler(void);
void timer_sleep_until(uint32_t time);
