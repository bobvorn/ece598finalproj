extern int scheduling_enabled;

void schedule(void);
int32_t sched_yield(void);
