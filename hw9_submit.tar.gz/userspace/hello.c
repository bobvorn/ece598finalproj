#include <stddef.h>
#include <stdint.h>
#include "syscalls.h"
#include "vlibc.h"

int main(int argc, char **argv) {

	printf("Hello World!\n");

	exit(5);

	return 0;
}
